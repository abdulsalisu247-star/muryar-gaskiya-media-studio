# Muryar Gaskiya Media Studio — Backend starter

This starter adds:
- A Flask backend that serves the existing studio website.
- A contact form that saves enquiries to a SQLite database.
- An admin login at `/admin/login`.
- An admin dashboard to view enquiries and mark them New, In progress, or Completed.
- Basic input validation, a spam honeypot, session protections, and security headers.

## Important limitations
- This is a starter backend, not yet deployed online.
- The local SQLite database is suitable for a small prototype. On a hosting service, configure a persistent disk or move to a managed database before relying on it.
- Set `SECRET_KEY`, `ADMIN_USERNAME`, and a strong `ADMIN_PASSWORD` through the hosting provider's environment-variable settings. Do not commit real secrets to source control.
- HTTPS must be enabled before setting `COOKIE_SECURE=1`.
- The website does not collect NIN, BVN, OTPs, passwords or biometric data. Do not add these to the contact form or dashboard.
- Email notifications, file uploads, portfolio editing, backups, account recovery, stronger rate limiting and production monitoring are not included yet.
- Do not use Flask's built-in development server for public production traffic.

## Run locally on a computer
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment.
4. Install dependencies: `pip install -r requirements.txt`
5. Set environment variables. At minimum set a long `SECRET_KEY` and a strong `ADMIN_PASSWORD`.
6. Start locally: `python app.py`
7. Visit `http://127.0.0.1:5000` for the website and `http://127.0.0.1:5000/admin/login` for admin.

Example environment variables (Linux/macOS shell):
```bash
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export ADMIN_USERNAME="studioadmin"
export ADMIN_PASSWORD="choose-a-long-unique-password"
python app.py
```

For a production host, use its Python web-service deployment guide and start command such as:
`waitress-serve --host=0.0.0.0 --port=$PORT app:app`

Use a host with persistent storage or configure a managed database before going live.

import os
import re
import sqlite3
import secrets
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash, abort
from werkzeug.security import check_password_hash, generate_password_hash

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("DATA_DIR", APP_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "studio.sqlite3"

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    # Enable this environment variable only when HTTPS is configured by your host.
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=32 * 1024,
)
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", "")

def db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS enquiries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                reply TEXT NOT NULL,
                service TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'New'
            )
        """)

def admin_password_ok(candidate):
    if ADMIN_PASSWORD_HASH:
        return check_password_hash(ADMIN_PASSWORD_HASH, candidate)
    # Password is configured by the operator through environment variables.
    return bool(ADMIN_PASSWORD) and secrets.compare_digest(candidate, ADMIN_PASSWORD)

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/contact")
def create_contact():
    data = request.get_json(silent=True) or {}
    # Honeypot: bots often fill hidden fields; return a generic success to them.
    if str(data.get("website", "")).strip():
        return jsonify(ok=True, message="Received"), 201

    name = str(data.get("name", "")).strip()
    reply = str(data.get("reply", "")).strip()
    service = str(data.get("service", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or not reply or not message:
        return jsonify(error="Please complete your name, contact and project details."), 400
    if len(name) > 100 or len(reply) > 160 or len(service) > 100 or len(message) > 3000:
        return jsonify(error="One of the fields is too long. Please shorten it and try again."), 400
    # Explicitly reject identity-number collection; the website must not handle these.
    sensitive_patterns = [
        r"\bNIN\s*(?:number|no\.?|:)?\s*[:#-]?\s*\d{8,}\b",
        r"\bBVN\s*(?:number|no\.?|:)?\s*[:#-]?\s*\d{8,}\b",
        r"\b(?:OTP|one[- ]time password)\s*[:#-]?\s*\d{4,}\b",
    ]
    if any(re.search(pattern, message, re.IGNORECASE) for pattern in sensitive_patterns):
        return jsonify(error="For your safety, do not send NIN, BVN or OTP numbers here. Please remove them and submit the enquiry again."), 400

    allowed_services = {
        "Audio & Song Production", "Video Production", "Photography & Design",
        "Digital Promotion", "Voice-over & Narration", "Other",
        "NIN/BVN service enquiry"
    }
    if service not in allowed_services:
        service = "Other"

    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with db() as conn:
        conn.execute(
            "INSERT INTO enquiries (name, reply, service, message, created_at) VALUES (?, ?, ?, ?, ?)",
            (name, reply, service, message, created_at),
        )
    return jsonify(ok=True, message="Enquiry received"), 201

@app.get("/admin/login")
def admin_login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin_dashboard"))
    return render_template("login.html", error=None)

@app.post("/admin/login")
def admin_login_post():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if username == ADMIN_USERNAME and admin_password_ok(password):
        session.clear()
        session["admin_logged_in"] = True
        session["csrf_token"] = secrets.token_urlsafe(24)
        return redirect(url_for("admin_dashboard"))
    return render_template("login.html", error="Login details are incorrect."), 401

@app.get("/admin")
@admin_required
def admin_dashboard():
    with db() as conn:
        enquiries = conn.execute("SELECT * FROM enquiries ORDER BY id DESC LIMIT 500").fetchall()
    return render_template("dashboard.html", enquiries=enquiries, csrf=session.get("csrf_token", ""))

def verify_csrf():
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    if not expected or not secrets.compare_digest(sent, expected):
        abort(400, "Invalid security token. Refresh the page and try again.")

@app.post("/admin/enquiry/<int:enquiry_id>/status")
@admin_required
def update_status(enquiry_id):
    verify_csrf()
    status = request.form.get("status", "")
    if status not in {"New", "In progress", "Completed"}:
        abort(400)
    with db() as conn:
        conn.execute("UPDATE enquiries SET status = ? WHERE id = ?", (status, enquiry_id))
    flash("Enquiry status updated.")
    return redirect(url_for("admin_dashboard"))

@app.post("/admin/logout")
@admin_required
def admin_logout():
    verify_csrf()
    session.clear()
    return redirect(url_for("admin_login"))

@app.get("/health")
def health():
    return jsonify(status="ok")

init_db()

if __name__ == "__main__":
    # Local development only. Use a production WSGI server for public hosting.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
